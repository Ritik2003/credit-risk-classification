# Credit Risk Classification (Machine Learning Project)

This project predicts whether a loan applicant will default based on financial + behavioral features.
Dataset is highly imbalanced, so the focus is **recall** (catching risky customers).

## 🚀 Problem Overview
Banks lose money when defaulters are not detected.
So missing a positive case is **very costly**.

This project:
- Handles class imbalance  
- Trains a Random Forest classifier  
- Optimizes the model for recall  
- Evaluates performance properly  

## 🔧 Technologies Used
Python, Pandas, NumPy, Scikit-Learn

## 📁 Structure
credit-risk-classification/
├── data/
├── src/
│   └── model.py
├── requirements.txt
└── .gitignore
